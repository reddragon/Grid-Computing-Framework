/* RCP for Distributed Sort */

#include<iostream>
#include<cstdlib>
#include<string>
#include<vector>
#include<cstring>
#include<fstream>

using namespace std;

void unzip(vector<string> tasks)
{
	for(int i = 0; i < tasks.size(); i++)
			{
				system( (char *) ( ( "gunzip -f " + tasks[i] + "_op.tar.gz" ).c_str() ));
				system( (char *) ( ( "tar xf " + tasks[i] + "_op.tar" ).c_str()));
			}
}


void process(vector<string> tasks)
{
	ifstream ops[1000];
	ofstream fop;
	char buf[100];
	
	int i, flag = 1;
	fop.open("rcpoutput.out");
	for(i = 0; i < tasks.size(); i++)
	{
		ops[i].open((char *)(tasks[i] + ".out").c_str());
		string cmd;
		ops[i] >> cmd;
		if(cmd == "YES")
		{
			int key;
			ops[i] >> key;
			flag = 0;
			cout << endl << "Key Found. Algorithm successfully broken. Key is: " << key << endl;
			fop << "Key Found. Algorithm successfully broken. Key is: " << key << endl;
			ops[i].close();
			break;
		}
		ops[i].close();
	}
	if(flag)
	{
		cout << endl << "Key not found." << endl;
		fop << "Key not found." << endl;
	}
	
}

int main()
{
	vector<string> tasks;
	tasks.push_back("t1"); 	
	tasks.push_back("t2"); 
	tasks.push_back("t3"); 
	tasks.push_back("t4"); 
	tasks.push_back("t5"); 
	
	unzip(tasks);
	
	process(tasks);
	
	return 0;
}
