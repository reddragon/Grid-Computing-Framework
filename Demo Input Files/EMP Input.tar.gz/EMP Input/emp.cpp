#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

int main()
{
	ifstream td_file("tasks_done.emp");
	string temp;
	ofstream er_file("emp_response.emp");
	bool yes_found = false;
	while(td_file >> temp)
	{
		system( (char *) ( ( "gunzip -f " + temp + "_op.tar.gz" ).c_str() ));
		system( (char *) ( ( "tar xf " + temp + "_op.tar" ).c_str()));
		ifstream check((temp + (string)".out").c_str());
		string result;
		
		check >> result;
		if(result == "YES")
		{
			yes_found = true;
			check.close();
			er_file << 1 << endl;
			er_file << "STOP ALL";
		}
		check.close();
	}
	if(!yes_found)
		er_file << 1 << "CONTINUE ALL";
		
	er_file.close();
	td_file.close();
	return 0;
}
