#include<iostream>
#include<stdio.h>

using namespace std;

unsigned int crypt(unsigned int data, unsigned int key)
{
	return data ^ key;
}

int main()
{
	freopen("t5.in", "r", stdin);
	freopen("t5.out", "w", stdout);
	int enc = 3000023, data = 23;
	int start, end;
	cin >> start >> end;
	for(int i = start; i <= end; i++)
	{
		int dec = crypt(enc, i);
		if(dec == data)
		{
			cout << "YES " << i; return 0;
		}
	}
	cout << "NO";
	return 0;
}
