#include<iostream>
#include<cstdlib>
#include<sstream>
#include<fstream>

using namespace std;

int make_input_file(string fn, int elem, int max_range)
{
	ofstream ofs;
	ofs.open(fn.c_str());
	srand(time(NULL));
	ofs << elem << endl;
	for(int i = 0; i < elem; i++)
	{
		int num = rand() % max_range;
		ofs << num << endl;
		//cout << i << endl;
	}
	ofs.close();
	return 0;
}

int task_file_gen()
{
	int t = 50;
	ofstream ofs("pss_data");
	
	for(int i = 1; i <= t; i++)
	{
	
			ofs << "<task><taskid>t" << i << "</taskid>";
				ofs << "<taskpriority>  19 </taskpriority>\n\
\n\
				<dependencies> \n\
\n\
				</dependencies>\n\
				<tasktimeout>10</tasktimeout>\n\
				<networklatencytime>0.2</networklatencytime>\n\
				<tasksourcepath>\n\
							<ts>t"<<i<<".cpp</ts>\n\
				</tasksourcepath>\n\
\
				<taskinputsetpath>\n\
							<ti>t"<<i<<".inp</ti>\n\
				</taskinputsetpath>\n\
					\n\
				<taskoutputsetpath>\n	\
							<to>t"<<i<<".out</to>\n\
				</taskoutputsetpath>	\n\
			<taskcompilecommand>		\n\
							<tc>g++ -o t"<<i<<" t"<<i<<".cpp</tc>\n\
			</taskcompilecommand>\n\
\n\
			<taskexecutioncommand>./t"<<i<<"</taskexecutioncommand>\n\
			</task>" << endl;
	}
}

int main()
{
	int tot = 50;
	int min_el = 100000, max_el = 500000, max_range = 10000000;
	/*
	for(int i = 1; i <= tot; i++)
	{
		stringstream ss;
		ss << "t" << i << ".inp";
		make_input_file(ss.str(), 100000, max_range);
		cout << i << endl;
	}*/
	task_file_gen();
	return 0;
}
