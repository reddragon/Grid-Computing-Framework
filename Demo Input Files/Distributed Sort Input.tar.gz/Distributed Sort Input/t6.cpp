
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<algorithm>
#include<cstring>
#define SZ 1000000
using namespace std;
vector<int> arr;
int n;
 
int main()
{
	string file_name = (string)(__FILE__);
	string taskid = file_name.substr(0, file_name.size() - 4);
	
	char inp_file[100];
	char op_file[100];
	sprintf(inp_file, "%s.inp", taskid.c_str());
	sprintf(op_file, "%s.out", taskid.c_str());
	
	freopen(inp_file, "r", stdin);
	freopen(op_file, "w", stdout);
	int temp;
	scanf("%d",&n);
	
	for(int i = 0; i < n; i++)
	{
		scanf("%d",&temp);
		arr.push_back(temp);
	}

	sort(arr.begin(),arr.end());
	
	for(int i = 0; i < n; i++)
	{
		printf("%d\n", arr[i]);
	}
	return 0;	
}
